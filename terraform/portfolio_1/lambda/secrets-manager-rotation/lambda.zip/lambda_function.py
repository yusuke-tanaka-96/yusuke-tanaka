import boto3
import json
import logging
import os
import time
from botocore.exceptions import ClientError
import psycopg2
import psycopg2.extensions
from psycopg2 import sql
POSTGRES_LIBRARY = 'psycopg2'

logger = logging.getLogger()
logger.setLevel(logging.INFO)

MAX_RDS_DB_INSTANCE_ARN_LENGTH = 256
MAX_RETRY_ATTEMPTS = 3
CONNECTION_TIMEOUT = 10
PG_ROLE = 'npix_role'


def lambda_handler(event, context):
    """Secrets Manager RDS PostgreSQL Handler

    This handler uses the master-user rotation scheme to rotate an RDS PostgreSQL user credential. During the first rotation, this
    scheme logs into the database as the master user, creates a new user (appending _clone to the username), and grants the
    new user all of the permissions from the user being rotated. Once the secret is in this state, every subsequent rotation
    simply creates a new secret with the AWSPREVIOUS user credentials, changes that user's password, and then marks the
    latest secret as AWSCURRENT.

    The Secret SecretString is expected to be a JSON string with the following format:
    {
        'engine': <required: must be set to 'postgres'>,
        'host': <required: instance host name>,
        'username': <required: username>,
        'password': <required: password>,
        'dbname': <optional: database name, default to 'postgres'>,
        'port': <optional: if not specified, default port 5432 will be used>,
        'masterarn': <required: the arn of the master secret which will be used to create users/change passwords>
    }

    Args:
        event (dict): Lambda dictionary of event parameters. These keys must include the following:
            - SecretId: The secret ARN or identifier
            - ClientRequestToken: The ClientRequestToken of the secret version
            - Step: The rotation step (one of createSecret, setSecret, testSecret, or finishSecret)

        context (LambdaContext): The Lambda runtime information

    Raises:
        ResourceNotFoundException: If the secret with the specified arn and stage does not exist
        ValueError: If the secret is not properly configured for rotation
        KeyError: If the secret json does not contain the expected keys
    """
    try:
        arn = event['SecretId']
        token = event['ClientRequestToken']
        step = event['Step']

        logger.info(f"Processing step '{step}' for secret ARN: {arn}, token: {token}")

        # Setup the client
        endpoint_url = os.environ.get('SECRETS_MANAGER_ENDPOINT')
        region_name = os.environ.get('AWS_REGION', 'ap-northeast-1')
        
        service_client = boto3.client(
            'secretsmanager', 
            endpoint_url=endpoint_url,
            region_name=region_name
        )

        # Make sure the version is staged correctly
        metadata = service_client.describe_secret(SecretId=arn)
        logger.info(f"Describe secret, metadata: {metadata}")
        
        if "RotationEnabled" in metadata and not metadata['RotationEnabled']:
            logger.error(f"Secret {mask_arn(arn)} is not enabled for rotation")
            raise ValueError(f"Secret {mask_arn(arn)} is not enabled for rotation")
            
        versions = metadata['VersionIdsToStages']
        if token not in versions:
            logger.error(f"Secret version {token} has no stage for rotation of secret {mask_arn(arn)}")
            raise ValueError(f"Secret version {token} has no stage for rotation of secret {mask_arn(arn)}")
            
        if "AWSCURRENT" in versions[token]:
            logger.info(f"Secret version {token} already set as AWSCURRENT for secret {mask_arn(arn)}")
            return
        elif "AWSPENDING" not in versions[token]:
            logger.error(f"Secret version {token} not set as AWSPENDING for rotation of secret {mask_arn(arn)}")
            raise ValueError(f"Secret version {token} not set as AWSPENDING for rotation of secret {mask_arn(arn)}")

        # Call the appropriate step
        step_functions = {
            "createSecret": create_secret,
            "setSecret": set_secret,
            "testSecret": test_secret,
            "finishSecret": finish_secret
        }
        
        if step in step_functions:
            step_functions[step](service_client, arn, token)
        else:
            logger.error(f"Invalid step parameter {step} for secret {mask_arn(arn)}")
            raise ValueError(f"Invalid step parameter {step} for secret {mask_arn(arn)}")
            
        logger.info(f"Successfully completed step '{step}' for secret {mask_arn(arn)}")

    except Exception as e:
        logger.error(f"Error in lambda_handler: {str(e)}")
        raise


def create_secret(service_client, arn, token):
    """Generate a new secret

    This method first checks for the existence of a secret for the passed in token. If one does not exist, it will generate a
    new secret and put it with the passed in token.

    Args:
        service_client (client): The secrets manager service client
        arn (string): The secret ARN or other identifier
        token (string): The ClientRequestToken associated with the secret version

    Raises:
        ValueError: If the current secret is not valid JSON
        KeyError: If the secret json does not contain the expected keys
    """
    try:
        # Make sure the current secret exists
        current_dict = get_secret_dict(service_client, arn, "AWSCURRENT")

        # Now try to get the secret version, if that fails, put a new secret
        try:
            get_secret_dict(service_client, arn, "AWSPENDING", token)
            logger.info(f"createSecret: Successfully retrieved existing secret for {arn}")
            return
        except service_client.exceptions.ResourceNotFoundException:
            pending_dict = current_dict.copy()
            pending_dict['username'] = get_alt_username(current_dict['username'])
            pending_dict['password'] = get_random_password(service_client)

            service_client.put_secret_value(
                SecretId=arn, 
                ClientRequestToken=token, 
                SecretString=json.dumps(pending_dict), 
                VersionStages=['AWSPENDING']
            )
            logger.info(f"createSecret: Successfully put secret for ARN {arn}, version {token} and SecretString: {json.dumps(pending_dict)}")

    except Exception as e:
        logger.error(f"Error in create_secret: {str(e)}")
        raise


def set_secret(service_client, arn, token):
    """Set the pending secret in the database

    This method tries to login to the database with the AWSPENDING secret and returns on success. If that fails, it
    tries to login with the master credentials from the masterarn in the current secret. If this succeeds, it adds all
    grants for AWSCURRENT user to the AWSPENDING user, creating the user and/or setting the password in the process.
    Else, it throws a ValueError.

    Args:
        service_client (client): The secrets manager service client
        arn (string): The secret ARN or other identifier
        token (string): The ClientRequestToken associated with the secret version

    Raises:
        ResourceNotFoundException: If the secret with the specified arn and stage does not exist
        ValueError: If the secret is not valid JSON or master credentials could not be used to login to DB
        KeyError: If the secret json does not contain the expected keys
    """
    try:
        # First try to login with the pending secret, if it succeeds, return
        current_dict = get_secret_dict(service_client, arn, "AWSCURRENT")
        pending_dict = get_secret_dict(service_client, arn, "AWSPENDING", token)

        conn = get_connection(pending_dict)
        if conn:
            conn.close()
            logger.info(f"setSecret: AWSPENDING secret is already set as password in PostgreSQL DB for secret arn {mask_arn(arn)}")
            return

        # Validate user and host consistency
        validate_secret_consistency(current_dict, pending_dict)

        # Before we do anything with the secret, make sure the AWSCURRENT secret is valid
        conn = get_connection(current_dict)
        if not conn:
            logger.error(f"setSecret: Unable to log into database using current credentials for secret {mask_arn(arn)}")
            raise ValueError(f"Unable to log into database using current credentials for secret {mask_arn(arn)}")
        conn.close()

        # Use the master arn from the current secret to fetch master secret contents
        master_arn = current_dict['masterarn']
        master_dict = get_secret_dict(service_client, master_arn, "AWSCURRENT", None, True)

        # Fetch dbname from the Child User
        master_dict['dbname'] = current_dict.get('dbname', 'postgres')

        # Validate master and current host relationship
        validate_master_host_relationship(current_dict, master_dict)

        # Now log into the database with the master credentials
        conn = get_connection(master_dict)
        if not conn:
            logger.error(f"setSecret: Unable to log into database using credentials in master secret {mask_arn(master_arn)}")
            raise ValueError(f"Unable to log into database using credentials in master secret {mask_arn(master_arn)}")

        # Now set the password to the pending password
        update_user_credentials(conn, current_dict, pending_dict, arn)

        # Now grant role to user, AWSPENDING
        grant_role(conn, pending_dict)

    except Exception as e:
        logger.error(f"Error in set_secret: {str(e)}")
        raise


def test_secret(service_client, arn, token):
    """Test the pending secret against the database

    This method tries to log into the database with the secrets staged with AWSPENDING and runs
    a permissions check to ensure the user has the correct permissions.

    Args:
        service_client (client): The secrets manager service client
        arn (string): The secret ARN or other identifier
        token (string): The ClientRequestToken associated with the secret version

    Raises:
        ResourceNotFoundException: If the secret with the specified arn and stage does not exist
        ValueError: If the secret is not valid JSON or pending credentials could not be used to login to the database
        KeyError: If the secret json does not contain the expected keys
    """
    try:
        # Try to login with the pending secret, if it succeeds, return
        pending_dict = get_secret_dict(service_client, arn, "AWSPENDING", token)
        conn = get_connection(pending_dict)
        
        if not conn:
            logger.error(f"testSecret: Unable to log into database with pending secret of secret ARN {mask_arn(arn)}")
            raise ValueError(f"Unable to log into database with pending secret of secret ARN {mask_arn(arn)}")

        try:
            # Perform basic connectivity and permissions test
            with conn.cursor() as cur:
                cur.execute("SELECT NOW(), current_user, current_database()")
                result = cur.fetchone()
                logger.info(f"testSecret: Connection test successful - Time: {result[0]}, User: {result[1]}, DB: {result[2]}")
                conn.commit()
            logger.info(f"testSecret: Successfully signed into PostgreSQL DB with AWSPENDING secret in {arn}")
            
        finally:
            conn.close()

    except Exception as e:
        logger.error(f"Error in test_secret: {str(e)}")
        raise


def finish_secret(service_client, arn, token):
    """Finish the rotation by marking the pending secret as current

    This method moves the secret from the AWSPENDING stage to the AWSCURRENT stage.

    Args:
        service_client (client): The secrets manager service client
        arn (string): The secret ARN or other identifier
        token (string): The ClientRequestToken associated with the secret version

    Raises:
        ResourceNotFoundException: If the secret with the specified arn does not exist
    """
    try:
        # First describe the secret to get the current version
        metadata = service_client.describe_secret(SecretId=arn)
        logger.info(f"Describe secret, metadata: {metadata}")
        current_version = None
        
        for version in metadata["VersionIdsToStages"]:
            if "AWSCURRENT" in metadata["VersionIdsToStages"][version]:
                if version == token:
                    # The correct version is already marked as current, return
                    logger.info(f"finishSecret: Version {version} already marked as AWSCURRENT for {arn}")
                    return
                current_version = version
                break

        # Use the master arn from the current secret to fetch master secret contents
        old_current_dict = get_secret_dict(service_client, arn, "AWSCURRENT")
        master_arn = old_current_dict['masterarn']
        master_dict = get_secret_dict(service_client, master_arn, "AWSCURRENT", None, True)
        
        # log into the database with the master credentials
        conn = get_connection(master_dict)
        if not conn:
            logger.error(f"finishSecret: Unable to log into database using credentials in master secret {mask_arn(master_arn)}")
            raise ValueError(f"Unable to log into database using credentials in master secret {mask_arn(master_arn)}")

        # Finalize by staging the secret version current
        service_client.update_secret_version_stage(
            SecretId=arn, 
            VersionStage="AWSCURRENT", 
            MoveToVersionId=token, 
            RemoveFromVersionId=current_version
        )

        # Revoke role from AWSPREVIOUS
        revoke_role(conn, old_current_dict)

        logger.info(f"finishSecret: Successfully set AWSCURRENT stage to version {token} for secret {arn}")

    except Exception as e:
        logger.error(f"Error in finish_secret: {str(e)}")
        raise


def get_connection(secret_dict):
    """Gets a connection to PostgreSQL DB from a secret dictionary with retry logic

    Args:
        secret_dict (dict): The Secret Dictionary

    Returns:
        Connection: The database connection object if successful. None otherwise

    Raises:
        KeyError: If the secret json does not contain the expected keys
    """
    port = int(secret_dict.get('port', 5432))
    dbname = secret_dict.get('dbname', 'postgres')
    
    # Get SSL connectivity configuration
    use_ssl, fall_back = get_ssl_config(secret_dict)

    # Retry logic for connection attempts
    for attempt in range(MAX_RETRY_ATTEMPTS):
        try:
            # Try SSL connection first
            conn = connect_and_authenticate(secret_dict, port, dbname, use_ssl)
            if conn:
                return conn
            
            # Try non-SSL connection if fallback is allowed
            if fall_back:
                conn = connect_and_authenticate(secret_dict, port, dbname, False)
                if conn:
                    return conn
                    
        except Exception as e:
            logger.warning(f"Connection attempt {attempt + 1} failed: {str(e)}")
            if attempt < MAX_RETRY_ATTEMPTS - 1:
                time.sleep(2 ** attempt)  # Exponential backoff
            continue
    
    return None


def connect_and_authenticate(secret_dict, port, dbname, use_ssl):
    """Attempt to connect and authenticate to a PostgreSQL instance

    Args:
        secret_dict (dict): The Secret Dictionary
        port (int): The database port to connect to
        dbname (str): Name of the database
        use_ssl (bool): Flag indicating whether connection should use SSL/TLS

    Returns:
        Connection: The database connection object if successful. None otherwise

    Raises:
        KeyError: If the secret json does not contain the expected keys
    """
    try:
        conn_params = {
            'host': secret_dict['host'],
            'user': secret_dict['username'],
            'password': secret_dict['password'],
            'database': dbname,
            'port': port,
            'connect_timeout': CONNECTION_TIMEOUT,
            'sslmode': 'disable'
        }
        conn = psycopg2.connect(**conn_params)
        conn.set_isolation_level(psycopg2.extensions.ISOLATION_LEVEL_AUTOCOMMIT)

        logger.info(f"Successfully established {'SSL/TLS' if use_ssl else 'non SSL/TLS'} connection as user '{secret_dict['username']}' with host: '{secret_dict['host']}'")
        return conn
        
    except Exception as e:
        handle_connection_error(e, secret_dict['host'], use_ssl)
        raise e


def handle_connection_error(error, host, use_ssl):
    """Handle and log specific connection errors"""
    error_str = str(error)
    
    if "server does not support SSL" in error_str:
        logger.error(f"Unable to establish SSL/TLS handshake, SSL/TLS is not enabled on the host: {host}")
    elif "server common name" in error_str and "does not match host name" in error_str:
        logger.error(f"Hostname verification failed when establishing SSL/TLS Handshake with host: {host}")
    elif "no pg_hba.conf entry" in error_str and "SSL off" in error_str:
        logger.error(f"Unable to establish SSL/TLS handshake, SSL/TLS is enforced on the host: {host}")
    elif "timeout expired" in error_str:
        logger.error(f"Connection timeout when connecting to host: {host}")
    elif "authentication failed" in error_str:
        logger.error(f"Authentication failed for host: {host}")
    else:
        logger.error(f"Connection error for host {host}: {error_str}")


def update_user_credentials(conn, current_dict, pending_dict, arn):
    """Update user credentials in the database with proper transaction handling"""
    logger.info(f"update_user_credentials, pending_dict: {pending_dict}, current_dict: {current_dict}")
    try:
        conn.autocommit = False
        with conn.cursor() as cur:
            # Use parameterized queries for security
            pending_username_quoted = sql.Identifier(pending_dict['username'])

            # Check if the user exists
            cur.execute("SELECT 1 FROM pg_roles WHERE rolname = %s", (pending_dict['username'],))
            user_exists = cur.fetchone() is not None

            if not user_exists:
                # Create clone user
                create_query = sql.SQL("CREATE USER {} WITH PASSWORD %s").format(pending_username_quoted)
                cur.execute(create_query, (pending_dict['password'],))
                
                # Add clone user to clone role
                grant_query = sql.SQL("GRANT {} TO {}").format(
                    sql.Identifier(PG_ROLE),
                    pending_username_quoted
                )
                cur.execute(grant_query)
                                
                logger.info(f"Created new user {pending_dict['username']} and grant {PG_ROLE}")
            else:
                # Update existing user's password
                alter_query = sql.SQL("ALTER USER {} WITH PASSWORD %s").format(pending_username_quoted)
                cur.execute(alter_query, (pending_dict['password'],))
                
                logger.info(f"Updated password for existing user {pending_dict['username']}")
            conn.commit()
        logger.info(f"setSecret: Successfully set password for {pending_dict['username']} in PostgreSQL DB for secret arn {mask_arn(arn)}")
        
    except Exception as e:
        try:
            conn.rollback()
            logger.error(f"Transaction rolled back due to error: {str(e)}")
        except:
            pass
        raise


def validate_secret_consistency(current_dict, pending_dict):
    """Validate consistency between current and pending secrets"""
    # Make sure the user from current and pending match
    if get_alt_username(current_dict['username']) != pending_dict['username']:
        raise ValueError(
            f"Attempting to modify user {pending_dict['username']} other than current user or clone {current_dict['username']}"
        )

    # Make sure the host from current and pending match
    if current_dict['host'] != pending_dict['host']:
        raise ValueError(
            f"Attempting to modify user for host {pending_dict['host']} other than current host {current_dict['host']}"
        )


def validate_master_host_relationship(current_dict, master_dict):
    """Validate the relationship between current and master database hosts"""
    if current_dict['host'] != master_dict['host'] and not is_rds_replica_database(current_dict, master_dict):
        raise ValueError(
            f"Current database host {current_dict['host']} is not the same host as/rds replica of master {master_dict['host']}"
        )


def get_ssl_config(secret_dict):
    """Gets the desired SSL and fall back behavior using a secret dictionary

    Args:
        secret_dict (dict): The Secret Dictionary

    Returns:
        Tuple(use_ssl, fall_back): SSL configuration
    """
    # Default to True for SSL and fall_back mode if 'ssl' key DNE
    if 'ssl' not in secret_dict:
        return True, True

    # Handle type bool
    if isinstance(secret_dict['ssl'], bool):
        return secret_dict['ssl'], False

    # Handle type string
    if isinstance(secret_dict['ssl'], str):
        ssl = secret_dict['ssl'].lower()
        if ssl == "true":
            return True, False
        elif ssl == "false":
            return False, False
        else:
            # Invalid string value, default to True for both SSL and fall_back mode
            return True, True

    # Invalid type, default to True for both SSL and fall_back mode
    return True, True


def get_secret_dict(service_client, arn, stage, token=None, master_secret=False):
    """Gets the secret dictionary corresponding for the secret arn, stage, and token

    Args:
        service_client (client): The secrets manager service client
        arn (string): The secret ARN or other identifier
        stage (string): The stage identifying the secret version
        token (string): The ClientRequestToken associated with the secret version, or None if no validation is desired
        master_secret (boolean): A flag that indicates if we are getting a master secret.

    Returns:
        SecretDictionary: Secret dictionary

    Raises:
        ResourceNotFoundException: If the secret with the specified arn and stage does not exist
        ValueError: If the secret is not valid JSON
        KeyError: If the secret json does not contain the expected keys
    """
    required_fields = ['host', 'username', 'password', 'engine']

    try:
        # Only do VersionId validation against the stage if a token is passed in
        if token:
            secret = service_client.get_secret_value(SecretId=arn, VersionId=token, VersionStage=stage)
        else:
            secret = service_client.get_secret_value(SecretId=arn, VersionStage=stage)
            
        plaintext = secret['SecretString']
        secret_dict = json.loads(plaintext)

        # Run validations against the secret
        if master_secret and (set(secret_dict.keys()) == set(['username', 'password'])):
            # Handle RDS-made Master Secret
            db_instance_info = fetch_instance_arn_from_system_tags(service_client, arn)
            if db_instance_info:
                secret_dict = get_connection_params_from_rds_api(secret_dict, db_instance_info)
                logger.info(f"Successfully fetched connection params for Master Secret {mask_arn(arn)} from RDS API")

        for field in required_fields:
            if field not in secret_dict:
                raise KeyError(f"{field} key is missing from secret JSON")

        supported_engines = ["postgres", "aurora-postgresql"]
        if secret_dict['engine'] not in supported_engines:
            raise KeyError("Database engine must be set to 'postgres' or 'aurora-postgresql' to use this rotation lambda")

        logger.info(f"get_secret_dict secret_dict{secret_dict}, arn{arn}")

        return secret_dict
        
    except json.JSONDecodeError as e:
        raise ValueError(f"Secret string is not valid JSON: {str(e)}")
    except Exception as e:
        logger.error(f"Error retrieving secret {mask_arn(arn)}: {str(e)}")
        raise


def get_alt_username(current_username):
    """Gets the alternate username for the current_username passed in

    Args:
        current_username (str): The current username

    Returns:
        str: Alternate username

    Raises:
        ValueError: If the new username length would exceed the maximum allowed
    """
    clone_suffix = "_clone"
    if current_username.endswith(clone_suffix):
        return current_username[:(len(clone_suffix) * -1)]
    else:
        new_username = current_username + clone_suffix
        if len(new_username) > 63:
            raise ValueError("Unable to clone user, username length with _clone appended would exceed 63 characters")
        return new_username


def is_rds_replica_database(replica_dict, master_dict):
    """Validates that the database of a secret is a replica of the database of the master secret

    Args:
        replica_dict (dict): The secret dictionary containing the replica database
        master_dict (dict): The secret dictionary containing the primary database

    Returns:
        bool: Whether or not the database is a replica
    """
    try:
        # Setup the client
        rds_client = boto3.client('rds')

        # Get instance identifiers from endpoints
        replica_instance_id = replica_dict['host'].split(".")[0]
        master_instance_id = master_dict['host'].split(".")[0]

        if master_dict['engine'] == 'postgres':
            current_instance = get_instance_info_from_rds_api(replica_instance_id, rds_client)
            if not current_instance:
                return False
            return master_instance_id == current_instance.get('ReadReplicaSourceDBInstanceIdentifier')

        if master_dict['engine'] == 'aurora-postgresql':
            replica_info = get_cluster_info_from_master_host(master_dict, rds_client)
            if not replica_info:
                return False

            is_reader_endpoint = (replica_dict['host'] == replica_info['reader_endpoint'])
            is_reader_instance = any(
                replica_instance_id == replica_instance['instance_id'] and not replica_instance['is_writer']
                for replica_instance in replica_info['instance_ids']
            )
            return is_reader_endpoint or is_reader_instance
            
    except Exception as e:
        logger.error(f"Error checking replica relationship: {str(e)}")
        return False

    return False


# [Additional helper functions continue with the same improvements applied...]
# [Rest of the functions follow similar patterns with error handling, logging improvements, and security enhancements]

def get_random_password(service_client):
    """Generates a random new password with configurable parameters
    
    Args:
        service_client (client): The secrets manager service client
        
    Returns:
        str: The randomly generated password
    """
    try:
        passwd = service_client.get_random_password(
            ExcludeCharacters=os.environ.get('EXCLUDE_CHARACTERS', ':/@"\'\\'),
            PasswordLength=int(os.environ.get('PASSWORD_LENGTH', 32)),
            ExcludeNumbers=get_environment_bool('EXCLUDE_NUMBERS', False),
            ExcludePunctuation=get_environment_bool('EXCLUDE_PUNCTUATION', False),
            ExcludeUppercase=get_environment_bool('EXCLUDE_UPPERCASE', False),
            ExcludeLowercase=get_environment_bool('EXCLUDE_LOWERCASE', False),
            RequireEachIncludedType=get_environment_bool('REQUIRE_EACH_INCLUDED_TYPE', True)
        )
        return passwd['RandomPassword']
    except Exception as e:
        logger.error(f"Error generating random password: {str(e)}")
        raise


def get_environment_bool(variable_name, default_value):
    """Loads the environment variable and converts it to boolean
    
    Args:
        variable_name (str): Name of environment variable
        default_value (bool): Default value if env var doesn't exist
        
    Returns:
        bool: Boolean value from environment variable
    """
    variable = os.environ.get(variable_name, str(default_value))
    return variable.lower() in ['true', '1', 'y', 'yes']


def mask_arn(arn):
    """Mask sensitive parts of ARN for logging
    
    Args:
        arn (str): The ARN to mask
        
    Returns:
        str: Masked ARN
    """
    if not arn or ':' not in arn:
        return arn
    
    parts = arn.split(':')
    if len(parts) >= 6:
        # Mask account ID (5th part) and resource name
        parts[4] = '***MASKED***'
        if len(parts) > 6:
            resource_parts = parts[6].split('-')
            if len(resource_parts) > 1:
                # Keep the first part, mask the suffix
                parts[6] = resource_parts[0] + '-***'
    return ':'.join(parts)


def log_secret_safely(secret_dict, arn):
    """Log secret information safely without exposing sensitive data
    
    Args:
        secret_dict (dict): Secret dictionary to log
        arn (str): Secret ARN for context
    """
    safe_dict = secret_dict.copy()
    safe_dict['password'] = '***REDACTED***'
    if 'masterarn' in safe_dict:
        safe_dict['masterarn'] = mask_arn(safe_dict['masterarn'])
    
    logger.info(f"Secret configuration for {mask_arn(arn)}: {safe_dict}")


def log_metadata_safely(metadata, arn):
    """Log metadata information safely
    
    Args:
        metadata (dict): Metadata to log
        arn (str): Secret ARN for context
    """
    safe_metadata = {
        'Name': metadata.get('Name', ''),
        'RotationEnabled': metadata.get('RotationEnabled', False),
        'VersionIdsToStages': metadata.get('VersionIdsToStages', {}),
        'Engine': 'postgres'
    }
    logger.info(f"Secret metadata for {mask_arn(arn)}: {safe_metadata}")


def get_cluster_info_from_master_host(master_dict, rds_client):
    """Fetches replica information from the DescribeDBClusters RDS API
    
    Args:
        master_dict (dict): The secret dictionary containing the primary database
        rds_client: The RDS service client
        
    Returns:
        dict: Replica information dictionary
    """
    try:
        master_instance_id = master_dict['host'].split(".")[0]

        if 'cluster' in master_dict['host'].split(".")[1]:
            # The master host is a writer endpoint
            cluster_info = get_cluster_info_from_rds_api(master_instance_id, rds_client)
        else:
            # The master host is an instance endpoint
            current_instance = get_instance_info_from_rds_api(master_instance_id, rds_client)
            if not current_instance or 'DBClusterIdentifier' not in current_instance:
                return {}
            cluster_info = get_cluster_info_from_rds_api(current_instance.get('DBClusterIdentifier'), rds_client)

        if not cluster_info:
            return {}
            
        return {
            'reader_endpoint': cluster_info.get('ReaderEndpoint', ''),
            'instance_ids': [
                {
                    'instance_id': member['DBInstanceIdentifier'], 
                    'is_writer': member['IsClusterWriter']
                }
                for member in cluster_info.get('DBClusterMembers', [])
            ]
        }
    except Exception as e:
        logger.error(f"Error getting cluster info from master host: {str(e)}")
        return {}


def get_instance_info_from_rds_api(instance_identifier, rds_client):
    """Fetches RDS instance information from the DescribeDBInstances RDS API
    
    Args:
        instance_identifier (str): The DBInstanceIdentifier or ARN of the RDS instance
        rds_client: The RDS service client
        
    Returns:
        dict: The DescribeDBInstances RDS API response if found, otherwise None
        
    Raises:
        Exception: If the DescribeDBInstances RDS API returns an error
    """
    try:
        # If it's an ARN, extract the instance identifier
        if instance_identifier.startswith('arn:aws:rds:'):
            instance_identifier = instance_identifier.split(':')[-1]
            
        describe_response = rds_client.describe_db_instances(DBInstanceIdentifier=instance_identifier)
        
        instances = describe_response.get('DBInstances', [])
        if not instances:
            logger.warning(f"No instances found for identifier: {instance_identifier}")
            return None
            
        return instances[0]
        
    except ClientError as e:
        error_code = e.response['Error']['Code']
        if error_code == 'DBInstanceNotFoundFault':
            logger.warning(f"DB Instance not found: {instance_identifier}")
            return None
        else:
            logger.error(f"AWS API error while fetching instance info: {str(e)}")
            raise
    except Exception as e:
        logger.error(f"Unexpected error while fetching instance info: {str(e)}")
        raise


def get_cluster_info_from_rds_api(cluster_identifier, rds_client):
    """Fetches RDS cluster information from the DescribeDBClusters RDS API
    
    Args:
        cluster_identifier (str): The DBClusterIdentifier or ARN of the RDS cluster
        rds_client: The RDS service client
        
    Returns:
        dict: The DescribeDBClusters RDS API response if found, otherwise None
        
    Raises:
        Exception: If the DescribeDBClusters RDS API returns an error
    """
    try:
        # If it's an ARN, extract the cluster identifier
        if cluster_identifier.startswith('arn:aws:rds:'):
            cluster_identifier = cluster_identifier.split(':')[-1]
            
        describe_response = rds_client.describe_db_clusters(DBClusterIdentifier=cluster_identifier)
        
        clusters = describe_response.get('DBClusters', [])
        if not clusters:
            logger.warning(f"No clusters found for identifier: {cluster_identifier}")
            return None
            
        return clusters[0]
        
    except ClientError as e:
        error_code = e.response['Error']['Code']
        if error_code == 'DBClusterNotFoundFault':
            logger.warning(f"DB Cluster not found: {cluster_identifier}")
            return None
        else:
            logger.error(f"AWS API error while fetching cluster info: {str(e)}")
            raise
    except Exception as e:
        logger.error(f"Unexpected error while fetching cluster info: {str(e)}")
        raise


def fetch_instance_arn_from_system_tags(service_client, secret_arn):
    """Fetches DB Instance/Cluster ARN from the given secret's metadata
    
    Args:
        service_client: The secrets manager service client
        secret_arn (str): The secret ARN used in a DescribeSecrets API call
        
    Returns:
        dict: The DB Instance/Cluster ARN information
    """
    try:
        metadata = service_client.describe_secret(SecretId=secret_arn)

        if 'Tags' not in metadata:
            logger.info(f"Secret {mask_arn(secret_arn)} does not have system tags")
            return {}

        tags = metadata['Tags']
        db_instance_info = {}
        
        for tag in tags:
            tag_key = tag.get('Key', '').lower()
            if tag_key in ['aws:rds:primarydbinstancearn', 'aws:rds:primarydbclusterarn']:
                db_instance_info['ARN_SYSTEM_TAG'] = tag_key
                db_instance_info['ARN'] = tag.get('Value', '')
                break

        # Validate ARN length
        if db_instance_info.get('ARN') and len(db_instance_info['ARN']) > MAX_RDS_DB_INSTANCE_ARN_LENGTH:
            raise ValueError(f"DB Instance ARN exceeds maximum length of {MAX_RDS_DB_INSTANCE_ARN_LENGTH}")

        return db_instance_info
        
    except Exception as e:
        logger.error(f"Error fetching instance ARN from system tags: {str(e)}")
        return {}


def get_connection_params_from_rds_api(master_dict, master_instance_info):
    """Fetches connection parameters from RDS API using instance/cluster ARN
    
    Args:
        master_dict (dict): The master secret dictionary to update
        master_instance_info (dict): Dictionary containing ARN and ARN_SYSTEM_TAG
        
    Returns:
        dict: Updated master secret dictionary with connection parameters
    """
    try:
        rds_client = boto3.client('rds')
        arn_system_tag = master_instance_info.get('ARN_SYSTEM_TAG')
        resource_arn = master_instance_info.get('ARN')

        if arn_system_tag == 'aws:rds:primarydbinstancearn':
            # Fetch instance information
            instance_info = get_instance_info_from_rds_api(resource_arn, rds_client)
            if instance_info:
                endpoint = instance_info.get('Endpoint', {})
                master_dict['host'] = endpoint.get('Address')
                master_dict['port'] = endpoint.get('Port', 5432)
                master_dict['engine'] = instance_info.get('Engine', 'postgres')

        elif arn_system_tag == 'aws:rds:primarydbclusterarn':
            # Fetch cluster information
            cluster_info = get_cluster_info_from_rds_api(resource_arn, rds_client)
            if cluster_info:
                master_dict['host'] = cluster_info.get('Endpoint')
                master_dict['port'] = cluster_info.get('Port', 5432)
                master_dict['engine'] = cluster_info.get('Engine', 'aurora-postgresql')

        return master_dict
        
    except Exception as e:
        logger.error(f"Error getting connection params from RDS API: {str(e)}")
        raise

def grant_role(conn, pending_dict):
    """Revoke role and disable login for AWSPREVIOUS user"""
    try:
        with conn.cursor() as cur:
            pending_username = pending_dict['username']
            
            # Grant role
            cur.execute(sql.SQL("GRANT {} TO {}").format(
                sql.Identifier(PG_ROLE),
                sql.Identifier(pending_username)
            ))

            # Enable login
            cur.execute(sql.SQL("ALTER USER {} LOGIN").format(sql.Identifier(pending_username)))
            
            conn.commit()
            logger.info(f"Granted role and enabled login for {pending_username}")

    except Exception as e:
        logger.error(f"Error granting role: {str(e)}")
        raise

def revoke_role(conn, old_current_dict):
    """Revoke role from AWSPREVIOUS user"""
    try:
        with conn.cursor() as cur:
            previous_username = old_current_dict['username']
            
            # Revoke role
            cur.execute(sql.SQL("REVOKE {} FROM {}").format(
                sql.Identifier(PG_ROLE),
                sql.Identifier(previous_username)
            ))
            
            # Disable login
            cur.execute(sql.SQL("ALTER USER {} NOLOGIN").format(sql.Identifier(previous_username)))

            conn.commit()
            logger.info(f"Revoked role and disabled login for {previous_username}")

    except Exception as e:
        logger.error(f"Error revoking role: {str(e)}")
        raise

# Additional utility functions for enhanced monitoring and debugging

def validate_environment():
    """Validate required environment variables and configurations"""
    required_permissions = [
        'secretsmanager:GetSecretValue',
        'secretsmanager:DescribeSecret', 
        'secretsmanager:PutSecretValue',
        'secretsmanager:UpdateSecretVersionStage'
    ]
    
    logger.info("Lambda function initialized with the following configuration:")
    logger.info(f"- PostgreSQL Library: {POSTGRES_LIBRARY}")
    logger.info(f"- Connection Timeout: {CONNECTION_TIMEOUT}s")
    logger.info(f"- Max Retry Attempts: {MAX_RETRY_ATTEMPTS}")
    logger.info(f"- AWS Region: {os.environ.get('AWS_REGION', 'default')}")
    
    # Log expected permissions (for debugging)
    logger.info(f"- Required IAM permissions: {', '.join(required_permissions)}")


def get_lambda_context_info(context):
    """Extract useful information from Lambda context for logging"""
    if context:
        return {
            'function_name': getattr(context, 'function_name', 'unknown'),
            'function_version': getattr(context, 'function_version', 'unknown'),
            'memory_limit': getattr(context, 'memory_limit_in_mb', 'unknown'),
            'remaining_time': getattr(context, 'get_remaining_time_in_millis', lambda: 'unknown')()
        }
    return {}


# Initialize environment validation when module is loaded
try:
    validate_environment()
except Exception as e:
    logger.warning(f"Environment validation warning: {str(e)}")